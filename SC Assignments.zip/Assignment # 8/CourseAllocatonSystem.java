// User class
public class User {
    private int userId;
    private String userName;
    private String password;

    public void login() {
        // For login
    }
}

// Student class
public class Student {
    private int studentId;
    private String studentName;
    private String department;
    private int programId;

    public void registerCourse() {
        // For registering a course
    }

    public void modifyRegisteredCourse() {
        // For modifying a registered course
    }

    public void viewRegisteredCourse() {
        // For viewing registered courses
    }

    public void viewFeeSubmissionStatus() {
        // For viewing fee submission status
    }

    public void viewAvailableCourse() {
        // For viewing available courses
    }
}

// Teacher class
public class Teacher {
    private int teacherId;
    private String teacherName;
    private String department;
}

// Admin class
public class Admin {
    private int adminId;
    private String adminName;
    private String department;
    private String role;
    private String adminPassword;

    public void offerCourses() {
        // For offering courses
    }

    public void modifyOfferedCourses() {
        // For modifying offered courses
    }

    public void maintainStudentRecord() {
        // For maintaining student records
    }

    public void maintainTeachersRecord() {
        // For maintaining teachers' records
    }

    public void maintainPaymentFeeData() {
        // For maintaining payment fee data
    }
}

// Courses class
public class Courses {
    private String courseCode;
    private String courseName;
    private int creditHours;
    private String programName;

    public void getCourseDetails() {
        // For modifying course details
    }
}

// FeePaymentData class
public class FeePaymentData {
    private int feeId;
    private String date;
    private String feeStatus;
    private int studentId;
    private int sessionId;

    public void verifyPaymentStatus() {
        // For verifying payment status
    }

}

// CourseRegistrationData class
public class CourseRegistrationData {
    private int registrationId;
    private int studentId;
    private int offId;

    public void getRegCoursesData() {
        // For getting registration courses data
    }
}

// OfferedCourse class
public class OfferedCourse {
    private int offId;
    private int sessionId;
    private String courseCode;

    public void getOfferedCoursesData() {
        // For getting offered courses data
    }
}

// PreRequisiteData class
public class PreRequisiteData {
    private int pId;
    private String courseCode;
    private int gradeId;

    public void getPreReqDetails() {
        // For getting prerequisite details
    }
}

public class semester {
    private int semester_id
    private int sessionId
    private int studentId

    public int getCourseslist() {
        // For getting Courses list for that semester
    }
}