import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CourseAllocationSystemInterface extends JFrame {
    private Map<String, List<String>> semesterCourses;

    public CourseAllocationSystemInterface() {
        super("Course Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 200);

        // Initialize semester courses map
        semesterCourses = new HashMap<>();

        // Start with user type selection button
        JButton userTypeButton = new JButton("Select User Type");
        userTypeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showUserTypeSelection();
            }
        });
        add(userTypeButton);

        // Set layout to FlowLayout
        setLayout(new FlowLayout());
    }

    private void showUserTypeSelection() {
        String[] userTypeOptions = { "Admin", "Student" };
        String selectedUserType = (String) JOptionPane.showInputDialog(this,
                "Select user type:",
                "User Type Selection",
                JOptionPane.QUESTION_MESSAGE,
                null,
                userTypeOptions,
                userTypeOptions[0]);

        if (selectedUserType != null) {
            switch (selectedUserType) {
                case "Admin":
                    showAdminPortal();
                    break;
                case "Student":
                    showStudentPortal();
                    break;
            }
        }
    }

    private void showAdminPortal() {
        // Open Admin Portal
        new AdminPortal().setVisible(true);
        // Close the initial interface
        this.dispose();
    }

    private void showStudentPortal() {
        // Open Student Portal
        new StudentPortal().setVisible(true);
        // Close the initial interface
        this.dispose();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CourseAllocationSystemInterface().setVisible(true));
    }
}

class AdminPortal extends JFrame {
    private Map<String, List<String>> semesterCourses;

    public AdminPortal() {
        super("Course Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 200);

        // Initialize semester courses map
        semesterCourses = new HashMap<>();

        // Admin login
        if (adminLogin()) {
            // After successful login, show course management options
            showCourseManagementOptions();
        } else {
            JOptionPane.showMessageDialog(this, "Login failed. Exiting...");
            System.exit(0);
        }
    }

    private boolean adminLogin() {
        String username = JOptionPane.showInputDialog(this, "Enter admin username:");
        String password = JOptionPane.showInputDialog(this, "Enter admin password:");

        // Replace the following condition with your actual authentication logic
        return "admin".equals(username) && "admin123".equals(password);
    }

    private void showCourseManagementOptions() {
        String[] options = { "Offer Courses", "Modify Offered Courses", "Show Offered Courses", "Exit" };
        int choice = JOptionPane.showOptionDialog(this, "Select an option:", "Course Management Options",
                JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

        switch (choice) {
            case 0:
                offerCourses();
                break;
            case 1:
                modifyOfferedCourses();
                break;
            case 2:
                showOfferedCourses();
                break;
            case 3:
                System.exit(0);
                break;
        }
    }

    private void offerCourses() {
        String semester = JOptionPane.showInputDialog(this, "Enter the semester for course offering:");
        if (semester != null && !semester.trim().isEmpty()) {
            allocateCourse(semester);
        } else {
            JOptionPane.showMessageDialog(this, "Invalid semester. Please try again.");
            offerCourses();
        }
    }

    private void allocateCourse(String semester) {
        List<String> availableCourses = getAvailableCourses();
        String[] coursesArray = availableCourses.toArray(new String[0]);
        String selectedCourse = (String) JOptionPane.showInputDialog(this,
                "Select a course to allocate:",
                "Course List",
                JOptionPane.QUESTION_MESSAGE,
                null,
                coursesArray,
                coursesArray[0]);

        if (selectedCourse != null) {
            // Check if the semester is already in the map
            if (!semesterCourses.containsKey(semester)) {
                semesterCourses.put(semester, new ArrayList<>());
            }

            semesterCourses.get(semester).add(selectedCourse);
            availableCourses.remove(selectedCourse); // Remove the allocated course from available courses
            JOptionPane.showMessageDialog(this,
                    "Course '" + selectedCourse + "' allocated successfully for Semester " + semester + "!");
        }

        // After allocating the course, show options again
        showCourseManagementOptions();
    }

    private void modifyOfferedCourses() {
        String semester = JOptionPane.showInputDialog(this, "Enter the semester to modify courses:");
        if (semester != null && semesterCourses.containsKey(semester)) {
            List<String> offeredCourses = semesterCourses.get(semester);

            if (!offeredCourses.isEmpty()) {
                String[] coursesArray = offeredCourses.toArray(new String[0]);
                String courseToRemove = (String) JOptionPane.showInputDialog(this,
                        "Select a course to remove:",
                        "Offered Courses",
                        JOptionPane.QUESTION_MESSAGE,
                        null,
                        coursesArray,
                        coursesArray[0]);

                if (courseToRemove != null) {
                    offeredCourses.remove(courseToRemove);
                    getAvailableCourses().add(courseToRemove); // Add the removed course back to available courses

                    // Display a list of available courses after removing the selected course
                    String[] remainingCoursesArray = getAvailableCourses().toArray(new String[0]);
                    String selectedCourse = (String) JOptionPane.showInputDialog(this,
                            "Select a course to offer:",
                            "Available Courses",
                            JOptionPane.QUESTION_MESSAGE,
                            null,
                            remainingCoursesArray,
                            remainingCoursesArray[0]);

                    if (selectedCourse != null) {
                        semesterCourses.get(semester).add(selectedCourse);
                        getAvailableCourses().remove(selectedCourse);
                        JOptionPane.showMessageDialog(this,
                                "Course '" + selectedCourse + "' offered successfully for Semester " + semester + "!");
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "No courses offered yet for Semester " + semester + ".");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Invalid semester or no courses offered for the given semester.");
        }

        // After modifying the offered courses, show options again
        showCourseManagementOptions();
    }

    private void showOfferedCourses() {
        if (semesterCourses.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No courses offered yet.");
        } else {
            StringBuilder message = new StringBuilder("Offered Courses:\n");
            for (Map.Entry<String, List<String>> entry : semesterCourses.entrySet()) {
                message.append("Semester ").append(entry.getKey()).append(":\n");
                for (String course : entry.getValue()) {
                    message.append(course).append("\n");
                }
            }
            JOptionPane.showMessageDialog(this, message.toString());
        }

        // After showing offered courses, show options again
        showCourseManagementOptions();
    }

    private List<String> getAvailableCourses() {
        // Replace this with your actual logic to fetch available courses
        return new ArrayList<>(Arrays.asList(
                "CS-414 AI ", "CS-322 SC ", "CS-311 ADA ", "CS-223 OS ",
                "BY-201 BIO ", "ST-101 STAT ", "CS-213 COAL", "CS-223 ADSS ", "CS-105 PSP ", "MA-203 DM ",
                " CS-121 OOP ", "CS-110 ICT ", "CS-225 DBS ", "CS-457 MAF ", "CS-331 TOA ", "CS-293 COAL LAB"));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AdminPortal().setVisible(true));
    }
}

class StudentPortal extends JFrame {
    private Map<String, Map<String, List<String>>> programs;
    private Map<String, List<String>> registeredCoursesBySemester;
    private String selectedProgram;
    private String selectedSemester;

    public StudentPortal() {
        super("Course Registration Interface");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 200);

        // Initializing programs with associated semesters and courses
        programs = new HashMap<>();
        programs.put("BS", createSemesterCoursesForBS());
        programs.put("MPhil", createSemesterCoursesForMPhilPhD());
        programs.put("PhD", createSemesterCoursesForMPhilPhD());

        // Initialize registered courses
        registeredCoursesBySemester = new HashMap<>();

        // Start with program selection button
        JButton programButton = new JButton("Select Program");
        programButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showProgramSelection();
            }
        });
        add(programButton);

        // Set layout to FlowLayout
        setLayout(new FlowLayout());
    }

    private void showProgramSelection() {
        String[] programOptions = { "BS", "MPhil", "PhD" };
        selectedProgram = (String) JOptionPane.showInputDialog(this,
                "Select a program:",
                "Program Selection",
                JOptionPane.QUESTION_MESSAGE,
                null,
                programOptions,
                programOptions[0]);

        if (selectedProgram != null) {
            if ("BS".equals(selectedProgram) || "MPhil".equals(selectedProgram) || "PhD".equals(selectedProgram)) {
                // Proceed to semester selection only if the selected program is valid
                showSemesterSelection();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid program selected.");
            }
        }
    }

    private void showSemesterSelection() {
        Map<String, List<String>> semesterCoursesForProgram = programs.get(selectedProgram);
        if (semesterCoursesForProgram == null || semesterCoursesForProgram.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "No information available for the selected program: " + selectedProgram);
            return;
        }

        String[] semesterOptions = semesterCoursesForProgram.keySet().toArray(new String[0]);
        selectedSemester = (String) JOptionPane.showInputDialog(this,
                "Select a semester:",
                "Semester Selection",
                JOptionPane.QUESTION_MESSAGE,
                null,
                semesterOptions,
                semesterOptions[0]);

        if (selectedSemester != null) {
            // After selecting the semester, proceed to course registration options
            showCourseRegistrationOptions();
        }
    }

    private void showCourseRegistrationOptions() {
        String[] options = { "Available Courses", "Show Registered Courses", "Modify Registered Course", "Exit" };
        int choice = JOptionPane.showOptionDialog(this, "Select an option:", "Course Registration Options",
                JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

        switch (choice) {
            case 0:
                registerCourse();
                break;
            case 1:
                showRegisteredCourses();
                break;
            case 2:
                modifyRegisteredCourse();
                break;
            case 3:
                System.exit(0);
                break;
        }
    }

    private void registerCourse() {
        if (selectedProgram == null || selectedSemester == null) {
            JOptionPane.showMessageDialog(this, "Please select a program and semester first.");
            return;
        }

        Map<String, List<String>> semesterCoursesForProgram = programs.get(selectedProgram);
        List<String> coursesForSemester = semesterCoursesForProgram.get(selectedSemester);
        if (coursesForSemester == null) {
            JOptionPane.showMessageDialog(this, "No information available for Semester " + selectedSemester + ".");
            return;
        }

        String[] coursesArray = coursesForSemester.toArray(new String[0]);
        String selectedCourse = (String) JOptionPane.showInputDialog(this,
                "Select a course to register for Semester " + selectedSemester + ":",
                "Course List",
                JOptionPane.QUESTION_MESSAGE,
                null,
                coursesArray,
                coursesArray[0]);

        if (selectedCourse != null) {
            registeredCoursesBySemester.computeIfAbsent(selectedSemester, k -> new ArrayList<>()).add(selectedCourse);
            JOptionPane.showMessageDialog(this,
                    "Course '" + selectedCourse + "' registered successfully for Semester " + selectedSemester + "!");
        }

        // After registering the course, show options again
        showCourseRegistrationOptions();
    }

    private void showRegisteredCourses() {
        if (selectedProgram == null || selectedSemester == null) {
            JOptionPane.showMessageDialog(this, "Please select a program and semester first.");
            return;
        }

        if (registeredCoursesBySemester.containsKey(selectedSemester)) {
            List<String> semesterCourses = registeredCoursesBySemester.get(selectedSemester);
            if (semesterCourses.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No courses registered for Semester " + selectedSemester + ".");
            } else {
                StringBuilder message = new StringBuilder(
                        "Registered Courses for Semester " + selectedSemester + ":\n");
                for (String course : semesterCourses) {
                    message.append(course).append("\n");
                }
                JOptionPane.showMessageDialog(this, message.toString());
            }
        } else {
            JOptionPane.showMessageDialog(this, "No courses registered for Semester " + selectedSemester + ".");
        }

        // After showing registered courses, show options again
        showCourseRegistrationOptions();
    }

    private void modifyRegisteredCourse() {
        if (selectedProgram == null || selectedSemester == null) {
            JOptionPane.showMessageDialog(this, "Please select a program and semester first.");
            return;
        }

        if (registeredCoursesBySemester.containsKey(selectedSemester)) {
            List<String> semesterCourses = registeredCoursesBySemester.get(selectedSemester);
            if (semesterCourses.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No courses registered for Semester " + selectedSemester + ".");
            } else {
                String[] coursesArray = semesterCourses.toArray(new String[0]);
                String selectedCourse = (String) JOptionPane.showInputDialog(this,
                        "Select a course to modify for Semester " + selectedSemester + ":",
                        "Modify Course",
                        JOptionPane.QUESTION_MESSAGE,
                        null,
                        coursesArray,
                        coursesArray[0]);

                if (selectedCourse != null) {
                    // Perform modification (for simplicity, let's remove and re-register)
                    semesterCourses.remove(selectedCourse);
                    registerCourse(); // You can modify this method based on your actual modification logic
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "No courses registered for Semester " + selectedSemester + ".");
        }

        // After modifying the course, show options again
        showCourseRegistrationOptions();
    }

    private Map<String, List<String>> createSemesterCoursesForBS() {
        Map<String, List<String>> coursesForBS = new HashMap<>();
        coursesForBS.put("1", Arrays.asList("PSP", "Math", "English-1", "ICT"));
        coursesForBS.put("2", Arrays.asList("OOP", "Math-2", "English-2", "Islamiyat"));
        coursesForBS.put("3", Arrays.asList("DSA", "Math-3", "English-3", "ICO"));
        coursesForBS.put("4", Arrays.asList("Coal", "Math-4", "English-4", "ADSS"));
        coursesForBS.put("5",
                Arrays.asList("CS-414-AI V", "CS-223- OS", "CS-322-SC", "CS-311-ADA", "BY-201-BIO", "ST-101-STAT"));
        return coursesForBS;
    }

    private Map<String, List<String>> createSemesterCoursesForMPhilPhD() {
        // For MPhil and PhD, there is no information available, so an empty map is
        // returned
        return new HashMap<>();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new StudentPortal().setVisible(true));
    }
}
