import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StudentPortal extends JFrame {
    private Map<String, Map<String, List<String>>> programs; // Map to store programs and their associated semesters and
                                                             // courses
    private Map<String, List<String>> registeredCoursesBySemester;
    private String selectedProgram;
    private String selectedSemester;

    public StudentPortal() {
        super("Course Registration Interface");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 200);

        // Initializing programs with associated semesters and courses
        programs = new HashMap<>();
        programs.put("BS", createSemesterCoursesForBS());
        programs.put("MPhil", createSemesterCoursesForMPhilPhD());
        programs.put("PhD", createSemesterCoursesForMPhilPhD());

        // Initialize registered courses
        registeredCoursesBySemester = new HashMap<>();

        // Start with program selection button
        JButton programButton = new JButton("Select Program");
        programButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showProgramSelection();
            }
        });
        add(programButton);

        // Set layout to FlowLayout
        setLayout(new FlowLayout());
    }

    private void showProgramSelection() {
        String[] programOptions = { "BS", "MPhil", "PhD" };
        selectedProgram = (String) JOptionPane.showInputDialog(this,
                "Select a program:",
                "Program Selection",
                JOptionPane.QUESTION_MESSAGE,
                null,
                programOptions,
                programOptions[0]);

        if (selectedProgram != null) {
            if ("BS".equals(selectedProgram) || "MPhil".equals(selectedProgram) || "PhD".equals(selectedProgram)) {
                // Proceed to semester selection only if the selected program is valid
                showSemesterSelection();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid program selected.");
            }
        }
    }

    private void showSemesterSelection() {
        Map<String, List<String>> semesterCoursesForProgram = programs.get(selectedProgram);
        if (semesterCoursesForProgram == null || semesterCoursesForProgram.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "No information available for the selected program: " + selectedProgram);
            return;
        }

        String[] semesterOptions = semesterCoursesForProgram.keySet().toArray(new String[0]);
        selectedSemester = (String) JOptionPane.showInputDialog(this,
                "Select a semester:",
                "Semester Selection",
                JOptionPane.QUESTION_MESSAGE,
                null,
                semesterOptions,
                semesterOptions[0]);

        if (selectedSemester != null) {
            // After selecting the semester, proceed to course registration options
            showCourseRegistrationOptions();
        }
    }

    private void showCourseRegistrationOptions() {
        String[] options = { "Available Courses", "Show Registered Courses", "Modify Registered Course", "Exit" };
        int choice = JOptionPane.showOptionDialog(this, "Select an option:", "Course Registration Options",
                JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

        switch (choice) {
            case 0:
                registerCourse();
                break;
            case 1:
                showRegisteredCourses();
                break;
            case 2:
                modifyRegisteredCourse();
                break;
            case 3:
                System.exit(0);
                break;
        }
    }

    private void registerCourse() {
        if (selectedProgram == null || selectedSemester == null) {
            JOptionPane.showMessageDialog(this, "Please select a program and semester first.");
            return;
        }

        Map<String, List<String>> semesterCoursesForProgram = programs.get(selectedProgram);
        List<String> coursesForSemester = semesterCoursesForProgram.get(selectedSemester);
        if (coursesForSemester == null) {
            JOptionPane.showMessageDialog(this, "No information available for Semester " + selectedSemester + ".");
            return;
        }

        String[] coursesArray = coursesForSemester.toArray(new String[0]);
        String selectedCourse = (String) JOptionPane.showInputDialog(this,
                "Select a course to register for Semester " + selectedSemester + ":",
                "Course List",
                JOptionPane.QUESTION_MESSAGE,
                null,
                coursesArray,
                coursesArray[0]);

        if (selectedCourse != null) {
            registeredCoursesBySemester.computeIfAbsent(selectedSemester, k -> new ArrayList<>()).add(selectedCourse);
            JOptionPane.showMessageDialog(this,
                    "Course '" + selectedCourse + "' registered successfully for Semester " + selectedSemester + "!");
        }

        // After registering the course, show options again
        showCourseRegistrationOptions();
    }

    private void showRegisteredCourses() {
        if (selectedProgram == null || selectedSemester == null) {
            JOptionPane.showMessageDialog(this, "Please select a program and semester first.");
            return;
        }

        if (registeredCoursesBySemester.containsKey(selectedSemester)) {
            List<String> semesterCourses = registeredCoursesBySemester.get(selectedSemester);
            if (semesterCourses.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No courses registered for Semester " + selectedSemester + ".");
            } else {
                StringBuilder message = new StringBuilder(
                        "Registered Courses for Semester " + selectedSemester + ":\n");
                for (String course : semesterCourses) {
                    message.append(course).append("\n");
                }
                JOptionPane.showMessageDialog(this, message.toString());
            }
        } else {
            JOptionPane.showMessageDialog(this, "No courses registered for Semester " + selectedSemester + ".");
        }

        // After showing registered courses, show options again
        showCourseRegistrationOptions();
    }

    private void modifyRegisteredCourse() {
        if (selectedProgram == null || selectedSemester == null) {
            JOptionPane.showMessageDialog(this, "Please select a program and semester first.");
            return;
        }

        if (registeredCoursesBySemester.containsKey(selectedSemester)) {
            List<String> semesterCourses = registeredCoursesBySemester.get(selectedSemester);
            if (semesterCourses.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No courses registered for Semester " + selectedSemester + ".");
            } else {
                String[] coursesArray = semesterCourses.toArray(new String[0]);
                String selectedCourse = (String) JOptionPane.showInputDialog(this,
                        "Select a course to modify for Semester " + selectedSemester + ":",
                        "Modify Course",
                        JOptionPane.QUESTION_MESSAGE,
                        null,
                        coursesArray,
                        coursesArray[0]);

                if (selectedCourse != null) {
                    // Perform modification (for simplicity, let's remove and re-register)
                    semesterCourses.remove(selectedCourse);
                    registerCourse(); // You can modify this method based on your actual modification logic
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "No courses registered for Semester " + selectedSemester + ".");
        }

        // After modifying the course, show options again
        showCourseRegistrationOptions();
    }

    private Map<String, List<String>> createSemesterCoursesForBS() {
        Map<String, List<String>> coursesForBS = new HashMap<>();
        coursesForBS.put("1", Arrays.asList("PSP", "Math", "English-1", "ICT"));
        coursesForBS.put("2", Arrays.asList("OOP", "Math-2", "English-2", "Islamiyat"));
        coursesForBS.put("3", Arrays.asList("DSA", "Math-3", "English-3", "ICO"));
        coursesForBS.put("4", Arrays.asList("Coal", "Math-4", "English-4", "ADSS"));
        coursesForBS.put("5",
                Arrays.asList("CS-414-AI V", "CS-223- OS", "CS-322-SC", "CS-311-ADA", "BY-201-BIO", "ST-101-STAT"));
        return coursesForBS;
    }

    private Map<String, List<String>> createSemesterCoursesForMPhilPhD() {
        // For MPhil and PhD, there is no information available, so an empty map is
        // returned
        return new HashMap<>();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new StudentPortal().setVisible(true));
    }
}