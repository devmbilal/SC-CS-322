import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CourseManagementSystem extends JFrame {
    private Map<String, List<String>> semesterCourses;

    public CourseManagementSystem() {
        super("Course Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 200);

        // Initialize semester courses map
        semesterCourses = new HashMap<>();

        // Admin login
        if (adminLogin()) {
            // After successful login, show course management options
            showCourseManagementOptions();
        } else {
            JOptionPane.showMessageDialog(this, "Login failed. Exiting...");
            System.exit(0);
        }
    }

    private boolean adminLogin() {
        String username = JOptionPane.showInputDialog(this, "Enter admin username:");
        String password = JOptionPane.showInputDialog(this, "Enter admin password:");

        // Replace the following condition with your actual authentication logic
        return "admin".equals(username) && "admin123".equals(password);
    }

    private void showCourseManagementOptions() {
        String[] options = { "Offer Courses", "Modify Offered Courses", "Show Offered Courses", "Exit" };
        int choice = JOptionPane.showOptionDialog(this, "Select an option:", "Course Management Options",
                JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

        switch (choice) {
            case 0:
                offerCourses();
                break;
            case 1:
                modifyOfferedCourses();
                break;
            case 2:
                showOfferedCourses();
                break;
            case 3:
                System.exit(0);
                break;
        }
    }

    private void offerCourses() {
        String semester = JOptionPane.showInputDialog(this, "Enter the semester for course offering:");
        if (semester != null && !semester.trim().isEmpty()) {
            allocateCourse(semester);
        } else {
            JOptionPane.showMessageDialog(this, "Invalid semester. Please try again.");
            offerCourses();
        }
    }

    private void allocateCourse(String semester) {
        List<String> availableCourses = getAvailableCourses();
        String[] coursesArray = availableCourses.toArray(new String[0]);
        String selectedCourse = (String) JOptionPane.showInputDialog(this,
                "Select a course to allocate:",
                "Course List",
                JOptionPane.QUESTION_MESSAGE,
                null,
                coursesArray,
                coursesArray[0]);

        if (selectedCourse != null) {
            // Check if the semester is already in the map
            if (!semesterCourses.containsKey(semester)) {
                semesterCourses.put(semester, new ArrayList<>());
            }

            semesterCourses.get(semester).add(selectedCourse);
            availableCourses.remove(selectedCourse); // Remove the allocated course from available courses
            JOptionPane.showMessageDialog(this,
                    "Course '" + selectedCourse + "' allocated successfully for Semester " + semester + "!");
        }

        // After allocating the course, show options again
        showCourseManagementOptions();
    }

    private void modifyOfferedCourses() {
        String semester = JOptionPane.showInputDialog(this, "Enter the semester to modify courses:");
        if (semester != null && semesterCourses.containsKey(semester)) {
            List<String> offeredCourses = semesterCourses.get(semester);

            if (!offeredCourses.isEmpty()) {
                String[] coursesArray = offeredCourses.toArray(new String[0]);
                String courseToRemove = (String) JOptionPane.showInputDialog(this,
                        "Select a course to remove:",
                        "Offered Courses",
                        JOptionPane.QUESTION_MESSAGE,
                        null,
                        coursesArray,
                        coursesArray[0]);

                if (courseToRemove != null) {
                    offeredCourses.remove(courseToRemove);
                    getAvailableCourses().add(courseToRemove); // Add the removed course back to available courses

                    // Display a list of available courses after removing the selected course
                    String[] remainingCoursesArray = getAvailableCourses().toArray(new String[0]);
                    String selectedCourse = (String) JOptionPane.showInputDialog(this,
                            "Select a course to offer:",
                            "Available Courses",
                            JOptionPane.QUESTION_MESSAGE,
                            null,
                            remainingCoursesArray,
                            remainingCoursesArray[0]);

                    if (selectedCourse != null) {
                        semesterCourses.get(semester).add(selectedCourse);
                        getAvailableCourses().remove(selectedCourse);
                        JOptionPane.showMessageDialog(this,
                                "Course '" + selectedCourse + "' offered successfully for Semester " + semester + "!");
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "No courses offered yet for Semester " + semester + ".");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Invalid semester or no courses offered for the given semester.");
        }

        // After modifying the offered courses, show options again
        showCourseManagementOptions();
    }

    private void showOfferedCourses() {
        if (semesterCourses.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No courses offered yet.");
        } else {
            StringBuilder message = new StringBuilder("Offered Courses:\n");
            for (Map.Entry<String, List<String>> entry : semesterCourses.entrySet()) {
                message.append("Semester ").append(entry.getKey()).append(":\n");
                for (String course : entry.getValue()) {
                    message.append(course).append("\n");
                }
            }
            JOptionPane.showMessageDialog(this, message.toString());
        }

        // After showing offered courses, show options again
        showCourseManagementOptions();
    }

    private List<String> getAvailableCourses() {
        // Replace this with your actual logic to fetch available courses
        return new ArrayList<>(Arrays.asList(
                "CS-414 AI ", "CS-322 SC ", "CS-311 ADA ", "CS-223 OS ",
                "BY-201 BIO ", "ST-101 STAT ", "CS-213 COAL", "CS-223 ADSS ", "CS-105 PSP ", "MA-203 DM ",
                " CS-121 OOP ", "CS-110 ICT ", "CS-225 DBS ", "CS-457 MAF ", "CS-331 TOA ", "CS-293 COAL LAB"));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CourseManagementSystem().setVisible(true));
    }
}
