import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Login extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;

    public Login() {
        setTitle("Login Page");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 150);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(3, 2));

        panel.add(new JLabel("Username:"));
        usernameField = new JTextField();
        panel.add(usernameField);

        panel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        panel.add(passwordField);

        JButton loginButton = new JButton("Login");
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleLogin();
            }
        });
        panel.add(loginButton);

        add(panel);
    }

    private void handleLogin() {
        String username = usernameField.getText();
        char[] passwordChars = passwordField.getPassword();
        String password = new String(passwordChars);

        // For simplicity, let's assume a predefined set of users
        User[] users = {
                new Student(1, "student1", "password1"),
                new Student(2, "student2", "password2"),
                new Teacher(101, "teacher1", "teacherpass"),
                new Teacher(102, "teacher2", "teacherpass")
        };

        User loggedInUser = null;

        // Check if the entered credentials match any user
        for (User user : users) {
            if (user.authenticate(username, password)) {
                loggedInUser = user;
                break;
            }
        }

        if (loggedInUser != null) {
            JOptionPane.showMessageDialog(this,
                    "Login successful!\nUser type: " + loggedInUser.getClass().getSimpleName());
        } else {
            JOptionPane.showMessageDialog(this, "Login failed. Invalid username or password.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Login().setVisible(true);
            }
        });
    }
}

class User {
    private int userId;
    private String username;
    private String password;

    public User(int userId, String username, String password) {
        this.userId = userId;
        this.username = username;
        this.password = password;
    }

    public boolean authenticate(String enteredUsername, String enteredPassword) {
        return username.equals(enteredUsername) && password.equals(enteredPassword);
    }
}

class Student extends User {
    public Student(int userId, String username, String password) {
        super(userId, username, password);
    }
}

class Teacher extends User {
    public Teacher(int userId, String username, String password) {
        super(userId, username, password);
    }
}