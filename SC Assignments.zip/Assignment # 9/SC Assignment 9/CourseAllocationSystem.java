import java.util.ArrayList;

class User {
    protected int userId;
    protected String userName;
    protected String password;

    public User(int userId, String userName, String password) {
        this.userId = userId;
        this.userName = userName;
        this.password = password;
    }
}

class Student extends User {
    private int studentId;
    private String studentName;
    private String department;
    private String program_id;

    public Student(int userId, String userName, String password, int studentId, String studentName,
            String registrationNumber, String department, String programID) {
        super(userId, userName, password);
        this.studentId = studentId;
        this.studentName = studentName;
        this.department = department;
        this.program_id = programID;
    }

    public void registerCourses(int courseId) {
        // Implementation for registering courses
    }

    public void modifyRegisteredCourses(int regId) {
        // Implementation for modifying registered courses
    }

    public void viewRegisteredCourses(int regId) {
        // Implementation for viewing registered courses
    }

    public void viewAvailableCourses(int courseCode) {
        // Implementation for viewing available courses
    }

    public void viewFeePaymentDetails(int feeId) {
        // Implementation for viewing fee payment details
    }
}

class Teacher extends User {
    private int teacherId;
    private String teacherName;
    private String department;

    public Teacher(int userId, String userName, String password, int teacherId, String teacherName,
            String department) {
        super(userId, userName, password);
        this.teacherId = teacherId;
        this.teacherName = teacherName;
        this.department = department;
    }

    public void viewTeacherRecord(int teacherId, String teacherName, String department) {
        // Implementation for viewing teacher record
    }
}

class Admin extends User {
    private int adminId;
    private String adminName;
    private String department;
    private String role;
    private String admin_password;

    public Admin(int userId, String userName, String password, int adminId, String adminName,
            String department, String admin_password, String role) {
        super(userId, userName, password);
        this.adminId = adminId;
        this.adminName = adminName;
        this.department = department;
        this.role = role;
        this.admin_password = admin_password;
    }

    public void offerCourses(int offId) {
        // Implementation for offering courses
    }

    public void modifyOfferedCourses(int offId) {
        // Implementation for modifying offered courses
    }

    public void maintainStudentsRecord() {
        // Implementation for maintaining student records
    }

    public void maintainTeachersRecord() {
        // Implementation for maintaining teacher records
    }

    public void maintainFeePaymentData() {
        // Implementation for maintaining fee payment data
    }
}

class Courses {
    private int courseCode;
    private String courseName;
    private int creditHours;
    private int program_id;

    public Courses(int courseCode, String courseName, int creditHours, int program_id) {
        this.courseCode = courseCode;
        this.courseName = courseName;
        this.creditHours = creditHours;
        this.program_id = program_id;
    }

    public void ModifyCourseDetails(int courseCode) {
        // Implementation for getting available courses
    }
}

class Semester {
    private int semesterId;
    private int student_id;
    private int session_id;

    public Semester(int semesterId, int programId, int session_id) {
        this.semesterId = semesterId;
        this.student_id = programId;
        this.session_id = session_id;
    }

    public void getCourseList() {
        // Implementation for getting the course list
    }
}

class RegisteredCourses {
    private int regId;
    private int student_id;
    private ArrayList<Integer> offeredCourses;

    public RegisteredCourses(int regId, int student_id) {
        this.regId = regId;
        this.student_id = student_id;
        this.offeredCourses = new ArrayList<>();
    }

    public void getRegisteredCourseData(int regId) {
        // Implementation for getting registered course data
    }
}

class OfferedCourses {
    private int offeredId;
    private int courseCode;
    private int session_id;

    public OfferedCourses(int offeredId, int courseCode, int session_id) {
        this.offeredId = offeredId;
        this.session_id = session_id;
        this.courseCode = courseCode;
    }

    public void getOfferedCourseData(int offeredId) {
        // Implementation for getting offered course data
    }
}

class Program {
    private int programId;
    private int programDuration;
    private String programName;

    public Program(int programId, int programDuration, String programName) {
        this.programId = programId;
        this.programDuration = programDuration;
        this.programName = programName;
    }

    public void getProgramDetails(int programId) {
        // Implementation for getting program details
    }
}

class FeePaymentData {
    private int feeId;
    private String paymentStatus;
    private String date;
    private int studentId;
    private int session_id;

    public FeePaymentData(int feeId, String paymentStatus, String date, int studentId, int session_id) {
        this.feeId = feeId;
        this.paymentStatus = paymentStatus;
        this.date = date;
        this.studentId = studentId;
        this.session_id = session_id;
    }

    public void viewFeeStatus(int feeId) {
        // Implementation for viewing fee status
    }
}

class PreRequisiteData {
    private int P_id;
    private String course_code;
    private String grade_id;

    public PreRequisiteData(int P_id, String course_code, String grade_id) {
        this.P_id = P_id;
        this.course_code = course_code;
        this.grade_id = grade_id;
    }

    public void viewFeeStatus(int feeId) {
        // Implementation for viewing fee status
    }
}

public class CourseAllocationSystem {
    public static void main(String[] args) {

    }
}
