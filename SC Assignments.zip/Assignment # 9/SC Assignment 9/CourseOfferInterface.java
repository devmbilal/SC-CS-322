import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CourseOfferInterface extends JFrame {
    // Map to store offered courses categorized by semester
    private Map<String, List<String>> semesterCourses;

    // List of available courses
    private List<String> availableCourses;

    // Constructor for the CourseOfferInterface
    public CourseOfferInterface() {
        super("Course Allocation Interface");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 150);

        // Initialize available and allocated courses
        availableCourses = new ArrayList<>(Arrays.asList("CS-414 AI ", "CS-322 SC ", "CS-311 ADA ", "CS-223 OS ",
                "BY-201 BIO ", "ST-101 STAT ", "CS-213 COAL", "CS-223 ADSS ", "CS-105 PSP ", "MA-203 DM ",
                " CS-121 OOP ", "CS-110 ICT ", "CS-225 DBS ", "CS-457 MAF ", "CS-331 TOA ", "CS-293 COAL LAB"));
        semesterCourses = new HashMap<>();

        // Start directly with course offering options
        showCourseOfferingOptions();
    }

    // Method to display course offering options to the user
    private void showCourseOfferingOptions() {
        // Options for the user to select
        String[] options = { "Offer Courses", "Show Offered Courses", "Exit" };

        // Display options in a dialog box
        int choice = JOptionPane.showOptionDialog(this, "Select an option:", "Course Offering Options",
                JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

        // Perform actions based on user's choice
        switch (choice) {
            case 0:
                // If "Offer Courses" is selected, prompt user to enter the semester
                selectSemester();
                break;
            case 1:
                // If "Show Offered Courses" is selected, display the list of offered courses
                showAllocatedCourses();
                break;
            case 2:
                // If "Exit" is selected, close the application
                System.exit(0);
                break;
        }
    }

    // Method to prompt the user to enter the semester for course offering
    private void selectSemester() {
        String semester = JOptionPane.showInputDialog(this, "Enter the semester for course offering:");

        // Validate the entered semester
        if (semester != null && !semester.trim().isEmpty()) {
            // If a valid semester is entered, proceed to allocate courses for that semester
            allocateCourse(semester);
        } else {
            // If an invalid semester is entered, display an error message and prompt again
            JOptionPane.showMessageDialog(this, "Invalid semester. Please try again.");
            selectSemester();
        }
    }

    // Method to allocate a course for a specific semester
    private void allocateCourse(String semester) {
        String[] coursesArray = availableCourses.toArray(new String[0]);

        // Prompt the user to select a course from the available courses
        String selectedCourse = (String) JOptionPane.showInputDialog(this,
                "Select a course to allocate:",
                "Course List",
                JOptionPane.QUESTION_MESSAGE,
                null,
                coursesArray,
                coursesArray[0]);

        if (selectedCourse != null) {
            // Check if the semester is already in the map
            if (!semesterCourses.containsKey(semester)) {
                semesterCourses.put(semester, new ArrayList<>());
            }

            // Add the selected course to the list of offered courses for the specified
            // semester
            semesterCourses.get(semester).add(selectedCourse);
            availableCourses.remove(selectedCourse);

            // Display a success message
            JOptionPane.showMessageDialog(this,
                    "Course '" + selectedCourse + "' allocated successfully for Semester " + semester + "!");
        }

        // After allocating the course, show course offering options again
        showCourseOfferingOptions();
    }

    // Method to display the list of offered courses categorized by semester
    private void showAllocatedCourses() {
        if (semesterCourses.isEmpty()) {
            // If no courses are allocated, display a message
            JOptionPane.showMessageDialog(this, "No courses allocated yet.");
        } else {
            // If courses are allocated, build a message with the list of offered courses
            StringBuilder message = new StringBuilder("Allocated Courses:\n");
            for (Map.Entry<String, List<String>> entry : semesterCourses.entrySet()) {
                message.append("Semester ").append(entry.getKey()).append(":\n");
                for (String course : entry.getValue()) {
                    message.append(course).append("\n");
                }
            }
            // Display the message with the list of offered courses
            JOptionPane.showMessageDialog(this, message.toString());
        }

        // After showing allocated courses, show course offering options again
        showCourseOfferingOptions();
    }

    // Main method to start the application
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CourseOfferInterface().setVisible(true));
    }
}
